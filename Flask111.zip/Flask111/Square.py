from flask import Flask
app = Flask(__name__)

@app.route('/')
def square():
    b=n*n
    print("The square of number is : ",b)
n = int(input("Enter the number : "))
square()
if __name__ == '__main__':
    app.run(debug = True)
