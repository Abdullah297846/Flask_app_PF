from flask import Flask
import hashlib

app = Flask(__name__)

@app.route('/md5')
def get_md5():
    file = r"C:\Users\Abdul\Desktop\fz.png" 
    with open(file , "rb") as f:
        image_bytes = f.read()

    md5_hash = str(hashlib.md5(image_bytes).hexdigest())

    return md5_hash

if __name__ == '__main__':
    app.run(debug=True)
